import {
  getTracks,
  getTrackById,
  createTrack,
  updateTrack,
  deleteTrack,
  deleteMultipleTracks,
  saveAudioFile,
  deleteAudioFile,
  getTrackBySlug,
  getGenres,
} from '../utils/db';
import { createSlug } from '../utils/slug';
import {
  Track,
  BatchDeleteResponse,
  UpdateTrackDto,
  QueryParams,
  PaginatedResponse,
  CreateTrackDto,
} from '../types';

interface DeleteTracksArgs {
  ids: string[];
}

interface UploadTrackFileArgs {
  id: string;
  file: any;
}

export const resolvers = {
  Query: {
    tracks: async (_: any, { params }: { params: QueryParams }) => {
      const query = params;
      const { tracks, total } = await getTracks(query);

      const page = query.page || 1;
      const limit = query.limit || 10;

      const response: PaginatedResponse<Track> = {
        data: tracks,
        meta: {
          total,
          page,
          limit,
          totalPages: Math.ceil(total / limit),
        },
      };

      return response;
    },
    track: async (_: any, { id }: { id: string }): Promise<Track> => {
      const track = await getTrackById(id);
      if (!track) {
        throw new Error('Track not found');
      }
      return track;
    },
    genres: async () => getGenres(),
  },
  Mutation: {
    addTrack: async (
      _: any,
      { data }: { data: CreateTrackDto }
    ): Promise<Track> => {
      const { title, artist, album, genres, coverImage } = data;

      if (!title || !artist) {
        throw new Error('Title and artist are required');
      }

      if (!genres || !Array.isArray(genres)) {
        throw new Error('Genres must be an array');
      }

      const slug = createSlug(title);

      const existingTrack = await getTrackBySlug(slug);
      if (existingTrack) {
        throw new Error('A track with this title already exists');
      }

      const newTrack = await createTrack({
        title,
        artist,
        album,
        genres,
        coverImage,
        slug,
      });

      return newTrack;
    },
    updateTrack: async (
      _: any,
      { id, data }: { id: string; data: UpdateTrackDto }
    ): Promise<Track> => {
      const { title } = data;

      const existingTrack = await getTrackById(id);
      if (!existingTrack) {
        throw new Error('Track not found');
      }

      let updates: Partial<UpdateTrackDto & { slug?: string }> = { ...data };

      if (title && title !== existingTrack.title) {
        const newSlug = createSlug(title);

        const trackWithSameSlug = await getTrackBySlug(newSlug);
        if (trackWithSameSlug && trackWithSameSlug.id !== id) {
          throw new Error('A track with this title already exists');
        }

        updates.slug = newSlug;
      }

      const updatedTrack = await updateTrack(id, updates);

      if (!updatedTrack) {
        throw new Error('Failed to update track');
      }

      return updatedTrack;
    },
    deleteTrack: async (_: any, { id }: { id: string }): Promise<boolean> => {
      const success = await deleteTrack(id);

      if (!success) {
        throw new Error('Track not found');
      }

      return true;
    },
    deleteTracks: async (
      _: any,
      { ids }: DeleteTracksArgs
    ): Promise<BatchDeleteResponse> => {
      if (!ids || !Array.isArray(ids) || ids.length === 0) {
        throw new Error('Track IDs are required');
      }
      const results = await deleteMultipleTracks(ids);
      return results;
    },
    deleteTrackFile: async (
      _: any,
      { id }: { id: string }
    ): Promise<Track | null> => {
      const existingTrack = await getTrackById(id);
      if (!existingTrack) {
        throw new Error('Track not found');
      }

      if (!existingTrack.audioFile) {
        throw new Error('Track has no audio file');
      }

      const success = await deleteAudioFile(id);

      if (!success) {
        throw new Error('Failed to delete audio file');
      }

      const updatedTrack = await getTrackById(id);

      return updatedTrack;
    },
    uploadTrackFile: async (
      _: any,
      { id, file }: { id: string, file: any }
    ): Promise<Track | null> => {
    
    const existingTrack = await getTrackById(id);
    if (!existingTrack) {
      throw new Error('Track not found');
    }
    
    if (!file) {
      throw new Error('No file uploaded');
    }
    // Validate file type
    const allowedMimeTypes = ['audio/mpeg', 'audio/wav', 'audio/mp3', 'audio/x-wav'];
    if (!allowedMimeTypes.includes(file.type)) {
      throw new Error('Invalid file type. Only MP3 and WAV files are allowed.');
    }
    
    // Get file buffer
    const arrayBuffer = await file.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);
    
    // Check file size (10MB limit)
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (buffer.length > maxSize) {
      throw new Error('File is too large. Maximum size is 10MB.');
    }
    
    // Save file and update track
    const fileName = await saveAudioFile(id, file.name, buffer);
    
    const updatedTrack = await updateTrack(id, { audioFile: fileName });
    
    return updatedTrack;
    }
  },
};
