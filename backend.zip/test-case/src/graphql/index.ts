import { createYoga, createSchema } from 'graphql-yoga';
import type { FastifyInstance } from 'fastify';
import { typeDefs } from './schema';
import { resolvers } from './resolvers';

export async function graphqlRoute(fastify: FastifyInstance) {
  const yoga = createYoga({
    schema: createSchema({
      typeDefs,
      resolvers,
    }),

    // fetchAPI:

    logging: {
      debug: (...args) => args.forEach((arg) => fastify.log.debug(arg)),
      info: (...args) => args.forEach((arg) => fastify.log.info(arg)),
      warn: (...args) => args.forEach((arg) => fastify.log.warn(arg)),
      error: (...args) => args.forEach((arg) => fastify.log.error(arg)),
    },
    graphqlEndpoint: '/api/graphql',
  });

  fastify.route({
    url: yoga.graphqlEndpoint,
    method: ['GET', 'POST', 'OPTIONS'],
    handler: async (req, reply) => {
      const response = await yoga.handleNodeRequestAndResponse(req, reply, {
        req,
        reply,
      } as any);
      response.headers.forEach((value, key) => {
        reply.header(key, value);
      });
      reply.status(response.status);
      reply.send(response.body);
      return reply;
    },
  });

  // This will allow Fastify to forward multipart requests to GraphQL Yoga
  fastify.addContentTypeParser(
    'multipart/form-data',
    {},
    (req, payload, done) => done(null)
  );
}
