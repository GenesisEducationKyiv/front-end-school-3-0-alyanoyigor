export const typeDefs = /* GraphQL */`
  scalar Upload

  type Query {
    tracks(params: TracksQueryParams): TracksQueryResponse
    track(id: ID!): Track
    genres: [String!]!
  }

  type Mutation {
    addTrack(
      data: AddTrackInput
    ): Track

    updateTrack(
      id: ID
      data: UpdateTrackInput
    ): Track

    deleteTrack(id: ID): Boolean

    deleteTracks(ids: [ID!]!): BatchDeleteResponse

    deleteTrackFile(id: ID): Track

    uploadTrackFile(
      id: ID
      file: Upload
    ): Track
  }

  type Track {
    id: ID!
    title: String!
    artist: String!
    album: String
    genres: [String!]!
    slug: String!
    coverImage: String
    audioFile: String
    createdAt: String!
    updatedAt: String!
  }

  input TracksQueryParams {
    page: Int
    limit: Int
    sort: String
    order: String
    search: String
    genre: String
    artist: String
  }

  input AddTrackInput {
    title: String!
    artist: String!
    album: String
    genres: [String!]!
    coverImage: String
  }

  input UpdateTrackInput {
    title: String
    artist: String
    album: String
    genres: [String!]
    coverImage: String
  }

  type BatchDeleteResponse {
    success: [ID!]!
    failed: [ID!]!
  }

  type TracksQueryResponse {
    data: [Track!]!
    meta: PaginationMeta!
  }

  type PaginationMeta {
    total: Int!
    page: Int!
    limit: Int!
    totalPages: Int!
  }
`;